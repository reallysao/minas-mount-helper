#!/bin/bash
# 小米智能存储 Finder 挂载助手 - App 启动器
# 内置 Python 运行时（mwdav_runtime，PyInstaller 打包），零外部依赖，Intel/Apple Silicon 通用。
# GUI 单实例：仅当无 GUI 主进程（mwdav_gui 无参数）时才启动；常驻服务（--service）不拦。
DIR="$(cd "$(dirname "$0")/../Resources" && pwd)"
cd "$DIR" || exit 1

if pgrep -f "mwdav_gui$" >/dev/null 2>&1; then
    exit 0
fi

exec "$DIR/mwdav_runtime/mwdav_gui" "$@"
