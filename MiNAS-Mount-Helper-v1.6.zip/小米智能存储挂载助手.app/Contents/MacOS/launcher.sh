#!/bin/bash
# 小米智能存储 Finder 挂载助手 - App 启动器
# GUI 单实例：仅当无 GUI 主进程（main.py 无参数）时才启动；常驻服务（--service）不拦。
# Python 查找链（通用 Mac 环境）：Homebrew → PATH → 系统。
DIR="$(cd "$(dirname "$0")/../Resources" && pwd)"
cd "$DIR" || exit 1

if pgrep -f "main\.py$" >/dev/null 2>&1; then
    exit 0
fi

PY=""
for c in \
    "/opt/homebrew/opt/python@3.13/bin/python3" \
    "/opt/homebrew/opt/python@3.12/bin/python3" \
    "/opt/homebrew/opt/python@3.11/bin/python3" \
    "/usr/local/opt/python@3.13/bin/python3" \
    "/usr/local/opt/python@3.12/bin/python3" \
    "/usr/local/opt/python@3.11/bin/python3" \
    "/opt/homebrew/bin/python3" \
    "/usr/local/bin/python3" \
    "python3"; do
    if [ "$c" = "python3" ]; then
        command -v "$c" >/dev/null 2>&1 || continue
    elif [ ! -x "$c" ]; then
        continue
    fi
    if "$c" -c "import ssl,tkinter; assert __import__('sys').version_info >= (3,10)" >/dev/null 2>&1; then
        PY="$c"
        break
    fi
done
[ -z "$PY" ] && PY="/usr/bin/python3"

exec "$PY" "$DIR/main.py" "$@"
